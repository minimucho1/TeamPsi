package com.psi.utascheduleplanner;

/**
 * Created by Dennis on 4/30/2015.
 */
public class DatabaseAdapter {

}
