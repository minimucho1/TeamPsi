package com.psi.utascheduleplanner;

/**
 * Created by laosd_000 on 4/28/2015.
 */

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Button;

// Selenium Library
import org.openqa.selenium.*;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Createfragment extends Fragment {
    // Variables
    View myFragmentView;
    EditText inputCourseSubject;
    EditText inputCourseNumber;
    CheckBox inputUseTimeRestrictions;
    Button inputSubmitButton;

    private String courseSubject;
    private String courseNumber;
    private String strN;
    private String classTimes[] = new String[100];
    private Boolean useTimeRestrictions;
    private WebElement courseSubjectElement;
    private WebElement courseNumberElement;
    private WebElement clickActionElement;
    private WebElement numberOfClassesElement;
    private WebDriver driver;


    // To show this Tab
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        myFragmentView = inflater.inflate(R.layout.createview, container, false);

        // Variables
        inputCourseSubject = (EditText) myFragmentView.findViewById(R.id.subject);
        inputCourseNumber = (EditText) myFragmentView.findViewById(R.id.courseNumber);
        inputUseTimeRestrictions = (CheckBox) myFragmentView.findViewById(R.id.useTimeRestrictions);
        inputSubmitButton = (Button) myFragmentView.findViewById(R.id.submitButton);

        inputSubmitButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Take In Entered Values
                courseSubject = inputCourseSubject.getText().toString();
                courseNumber = inputCourseNumber.getText().toString();
                if (inputUseTimeRestrictions.isChecked()) {
                    useTimeRestrictions = true;
                }
                else {
                    useTimeRestrictions = false;
                }

                // Start Connection
                driver = new HtmlUnitDriver(true);
                driver.get("https://sis-cs-prod.uta.edu/psc/ACSPRD/EMPLOYEE/PSFT_ACS/c/COMMUNITY_ACCESS.CLASS_SEARCH.GBL");

                // Load WebDrivers into Elements
                courseSubjectElement = (new WebDriverWait(driver,10)).until(ExpectedConditions.presenceOfElementLocated(By.id("SSR_CLSRCH_WRK_SUBJECT$0")));
                courseNumberElement = (new WebDriverWait(driver,10)).until(ExpectedConditions.presenceOfElementLocated(By.id("SSR_CLSRCH_WRK_CATALOG_NBR$1")));

                // Send Course Subject Data to MyMav
                courseSubjectElement.sendKeys(courseSubject);

                // Wait
                try {
                    Thread.sleep(2000);
                }
                catch (Exception e) {

                }

                // Send Course Number Data to MyMav
                courseNumberElement.sendKeys(courseNumber);

                // Submit Form
                courseNumberElement.submit();

                // Click Action
                clickActionElement = (new WebDriverWait(driver,10)).until(ExpectedConditions.presenceOfElementLocated(By.id("CLASS_SRCH_WRK2_SSR_PB_CLASS_SRCH")));
                clickActionElement.click();

                // Retrieve Number of Classes
                numberOfClassesElement = (new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.className("SSSGROUPBOX")));
                strN = (numberOfClassesElement.getText().toString()).replaceAll("\\D+", "");
                int numberOfClasses = Integer.parseInt(strN);

                for (int i = 0; i < numberOfClasses; i++){
                    courseNumberElement = (new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.id("MTG_DAYTIME$0")));
                    StringBuilder cTime = new StringBuilder();

                    //get id
                    cTime.append(courseNumberElement.getAttribute("id"));
                    //make element MTG_DAYTIME$
                    cTime.delete(12, 13);
                    //System.out.println(cTime);

                    //convert i to string
                    String iStr = Integer.toString(i);
                    //set element to MTG_DAYTIME$i
                    cTime.append(iStr);

                    //set element2
                    courseNumberElement = (new WebDriverWait(driver,30)).until(ExpectedConditions.presenceOfElementLocated(By.id(cTime.toString())));
                    classTimes[i] =  courseNumberElement.getText().toString();
                }

                for (int i = 0;i < numberOfClasses; i++){
                    Log.d("LOG_TAG", classTimes[i]);
                }

                driver.quit();
            }
        });



        return myFragmentView;
    }

}

